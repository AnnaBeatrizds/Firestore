package br.edu.fatecpg.appfirestore.views

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import br.edu.fatecpg.appfirestore.adapters.ProdutoAdapter
import br.edu.fatecpg.appfirestore.databinding.ActivityListBinding
import br.edu.fatecpg.appfirestore.models.Produto

class ListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListBinding
    private lateinit var adapter: ProdutoAdapter
    private var produtos: List<Produto> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        produtos = intent.getSerializableExtra("produtos") as? List<Produto> ?: emptyList()

        binding.recLista.layoutManager = LinearLayoutManager(this)

        adapter = ProdutoAdapter(produtos)
        binding.recLista.adapter = adapter
    }
}
